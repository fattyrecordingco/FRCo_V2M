"""Schema models package."""

