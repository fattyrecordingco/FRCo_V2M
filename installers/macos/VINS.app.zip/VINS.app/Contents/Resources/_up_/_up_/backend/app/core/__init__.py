"""Core config/constants package."""

